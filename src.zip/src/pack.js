const pack = (date, user, wame) => {
return `┏━🔥࿗ 𝑻𝒆𝒓𝒓𝒐𝒓 𝒓𝒆𝒊𝒅 𝑩𝒐𝒕 Ilimitado ࿗🔥━┓
║                                                           
║ _*🕐 𝐃𝐚𝐭𝐚 y 𝐡𝐨𝐫𝐚: ${date} 🕐*_
║ _*🙂 𝐔𝐬𝐮𝐚́𝐫𝐢𝐨: ${user} 🙂*_
║ _*🌎 𝐖𝐚𝐦𝐞: ${wame} 🌎*_                                        
║                                                           
┣══════𝑺𝒊𝒈𝒂 mis 𝒓𝒆𝒅𝒆𝒔 𝒔𝒐𝒄𝒊𝒂les══════┫
║
║ _*📷 𝐈𝐧𝐬𝐭𝐚𝐠𝐫𝐚𝐦:*_ fucku_alec
║
║ _*🤖𝐆𝐢𝐭𝐡𝐮𝐛:*_
║ _*🌐https://github.com/AlecMods🌐*_
║
║ _*📹 𝐘𝐨𝐮𝐭𝐮𝐛𝐞:*_
║ _*🌐https://YouTube.com/AlecMods🌐*_
║
┗════════════════════════┛
» 🥵𝙾𝚗𝚕𝚢𝚏𝚊𝚗𝚜 y 𝚑𝚎𝚗𝚝𝚊𝚒 en 𝚖𝚎𝚐𝚊🥵 «

❁❧ *FOTOS DE HENTAI 720MB:* 
_*🌐 https://suaurl.com/55eb2f 🌐*_

❁❧ *PRINCESS STARLING(ONLY FANS)8.36GB:* 
_*🌐 https://suaurl.com/b995e2 🌐*_

❁❧ *ELLES CLUB 28.68GB:* 
_*🌐 https://suaurl.com/8c135b 🌐*_

❁❧ *COCONUTKITTY(ONLY FANS)7.69GB:*
_*🌐 https://suaurl.com/5e91e0 🌐*_

❁❧ *Belle delphine:* 
_*🌐 https://suaurl.com/5c699d 🌐*_

❁❧ *Love Lilah:* 
_*🌐 https://suaurl.com/dbaae7 🌐*_

❁❧ *Hidori:* 
_*🌐 https://suaurl.com/f43f76 🌐*_`
}
exports.pack = pack
