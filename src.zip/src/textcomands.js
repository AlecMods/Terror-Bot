const textcomands = (p) => {
return `Sean Bienvenidos a este menu
💎 ▁▂▃༻𝑻𝒆𝒓𝒓𝒐𝒓 𝒓𝒆𝒊𝒅 𝑩𝒐𝒕 2.0༺▃▂▁ 💎
╔════ ❯ 𝓬𝓶𝓭 𝓭𝓮 𝓽𝓮𝔁𝓽𝓸 ❮ ══════════
║ ❯ *${p}glitch* <text1> | <text2>
║ ❯ *${p}ravetext* <text1> | <text2>
║ ❯ *${p}woodtext* <text1> | <text2>
║ ❯ *${p}neon* <text1> | <text2>
║ ❯ *${p}sunset* <text1> | <text2>
║ ❯ *${p}gimage* <text>
║ ❯ *${p}whatis* <text>
║ ❯ *${p}text3d* <text>
╚═══════════════════════════`
}
exports.textcomands = textcomands