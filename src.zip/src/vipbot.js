const vipbot = (prefix) => {
    return `✩｡:•.💎𝑻𝒆𝒓𝒓𝒐𝒓 𝒓𝒆𝒊𝒅 𝑩𝒐𝒕 𝒆𝒙𝒄𝒍𝒖𝒔𝒊𝒗𝒐💎.•:｡✩
★・・・★・・・ - ・・・★・・・★

🎉𝐒𝐮𝐩𝐨𝐫𝐭𝐞 𝐞𝐱𝐜𝐥𝐮𝐬𝐢𝐯𝐨: _*NIO$40,00🎉*_

🎉𝐀gregar 𝐜𝐦𝐝: _*NIO$100,00🎉*_

🎉𝐂𝐫ea𝐫 𝐧𝐮́𝐦𝐞𝐫𝐨: _*NIO$50,00 🎉*_

🎉𝐂𝐨́𝐝𝐢𝐠𝐨 𝐨𝐫𝐢𝐠𝐢𝐧𝐚𝐥: _*NIO$300,00🎉*_

🎉𝐎𝐭𝐫𝐨𝐬 𝐜𝐦𝐝𝐬: _*negociar con el creador🎉*_

🔰 𝑴𝒂𝒔 informacion🔰

_${prefix}𝐂𝐫eador 𝐩𝐚𝐫𝐚 𝐧𝐞𝐠𝐨𝐜𝐢𝐚𝐫_`
}
exports.vipbot = vipbot